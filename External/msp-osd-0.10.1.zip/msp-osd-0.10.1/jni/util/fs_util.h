#include <stdint.h>

int32_t get_int_from_fs(char* path);
void *open_dict(int dict_version, int *size);