int connect_to_server(char *address, int port);
int bind_socket(int port);