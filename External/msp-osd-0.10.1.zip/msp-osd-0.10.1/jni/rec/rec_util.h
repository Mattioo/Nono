#pragma once

#include <stdlib.h>

void rec_util_osd_path_from_video_path(const char *video_path, char *osd_path, size_t osd_path_size);
