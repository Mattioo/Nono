void dji_stop_goggles(int is_v2);
void dji_start_goggles(int is_v2);
int dji_goggles_are_v2();