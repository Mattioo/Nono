int get_boolean_config_value(const char* key);
const char *get_string_config_value(const char *key);
int get_integer_config_value(const char *key);